#pragma once
class Registro {
public:
    int dato;
    Registro(int valor);
};
