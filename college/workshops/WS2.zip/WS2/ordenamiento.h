#pragma once 
#include "nodo.h"
class Ordenamiento {
public:
    static Nodo* fusionarListas(Nodo* izquierda, Nodo* derecha);
    static Nodo* ordenamientoMisterio(Nodo* lista);
};