#include "nodo.h"
Nodo::Nodo(Registro *reg) : registro(reg),
siguiente(nullptr)
{
}
